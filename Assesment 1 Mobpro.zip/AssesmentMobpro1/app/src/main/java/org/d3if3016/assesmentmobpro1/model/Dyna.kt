package org.d3if3016.assesmentmobpro1.model

import androidx.annotation.DrawableRes

data class Dyna(
    val nama: String,
    @DrawableRes val imageResId: Int
)
